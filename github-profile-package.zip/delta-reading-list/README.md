# 📚 DELTA Reading List

A curated, module-by-module reading list for English language teachers preparing for the **Cambridge DELTA**, put together by **Dr. Alhusein Gasmallah**.

> The full visual version (slide deck) is in [`slides/`](./slides).

---

## Module 1: Understanding Language, Methodology and Resources

- Language systems: grammar, lexis, phonology, discourse
- Language skills: reading, listening, speaking, writing
- Key terminology and approaches to language teaching

<!-- TODO: paste the exact book titles/authors from your Delta_Reading_List slides -->

## Module 2: Developing Professional Practice

- Lesson planning and the Background Essay
- Classroom observation and reflective practice
- Learner analysis and needs analysis

## Module 3: Extending Practice / ELT Specialism

- Course design and syllabus planning
- Assessment and testing
- Specialism-specific reading (e.g. EAP, young learners, ESP)

---

## 💡 How to use this list

1. Start with one core text per module. Don't try to read everything.
2. Keep a reading log: key idea, page number and how it links to your lessons.
3. Use quotations sparingly in essays, and always cite correctly.

## 🤝 Contribute

Suggestions are welcome. Open an **Issue** with the title, author, year and why it helped you.
