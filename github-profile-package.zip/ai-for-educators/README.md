# 🤖 AI for Educators

Step-by-step, screenshot-based guides by **Dr. Alhusein Gasmallah** to help teachers and researchers start using AI assistants **safely, ethically and effectively**. Available in English and Arabic.

---

## 📘 Guides

| # | Guide | Level |
|---|---|---|
| 1 | Getting started with Claude: the home screen, your first chat, uploading files | Beginner |
| 2 | Writing good prompts for lesson planning | Beginner |
| 3 | Giving AI-assisted feedback on student writing (EFL) | Intermediate |
| 4 | Using AI to support literature searching (with Elicit and Litmaps) | Intermediate |
| 5 | Academic integrity: what AI should and shouldn't do in student work | All |

📁 Each guide lives in [`guides/`](./guides) as a Markdown page with screenshots in [`images/`](./images).

## ✍️ Prompt library for teachers

Ready-to-copy prompts in [`prompts/`](./prompts), for example:

```text
You are an experienced EFL writing tutor. Read the student paragraph below.
1. List the 5 most important grammar or vocabulary errors.
2. For each one, explain the rule simply (B1 level).
3. Do NOT rewrite the whole paragraph. Give hints so the student can correct it.

Paragraph:
"""<paste student text>"""
```

## ⚖️ Responsible-use checklist

- [ ] Never paste personal or identifiable student data
- [ ] Check every fact and reference the AI gives you
- [ ] Tell students when and how AI was used
- [ ] Follow your institution's AI policy

## 🗂️ Structure

```
ai-for-educators/
├── guides/        # en/ and ar/ versions
├── images/        # screenshots (e.g. step1-claude-home-screen.png)
├── prompts/       # prompt library
└── README.md
```

## 📄 License

[CC BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0/)
