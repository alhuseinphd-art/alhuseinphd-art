# Your GitHub setup guide (about 20 minutes)

Account: **github.com/alhuseinphd-art**

## Step 1: Profile settings
Go to **github.com → your photo (top right) → Settings → Public profile** and fill in:

| Field | Paste this |
|---|---|
| **Name** | Dr. Alhusein Gasmallah |
| **Bio** (160 characters max) | EFL educator & research-skills trainer · AI in education · Litmaps & Elicit workshops · Building open resources for teachers & researchers 🇶🇦 |
| **URL** | https://alhuseinphd-art.github.io |
| **Location** | Doha, Qatar |
| **Public email** | alhuseinphd@gmail.com (optional) |
| **Social accounts** | LinkedIn, ORCID, Google Scholar (when you have the links) |
| **Profile picture** | A clear, professional headshot |

Click **Update profile**.

## Step 2: Profile README (the big page visitors see first)
1. Click **+ (top right) → New repository**.
2. Name it exactly **`alhuseinphd-art`**. GitHub will say "✨ This is a special repository".
3. Tick **Public** and **Add a README file**, then click **Create repository**.
4. Open `README.md`, click ✏️ (Edit), delete everything, and paste the contents of `alhuseinphd-art/README.md` from this package.
5. Click **Commit changes**.

## Step 3: Personal website
1. Create a new **public** repository named exactly **`alhuseinphd-art.github.io`**.
2. Click **Add file → Upload files**, drag in `index.html`, then click **Commit**.
3. Go to **Settings → Pages**. Under *Source*, choose **Deploy from a branch**, pick **main** and **/(root)**, then click **Save**.
4. After 1–2 minutes your site is live at **https://alhuseinphd-art.github.io**.

## Step 4: Resource repositories
Create these 4 **public** repositories. For each one, upload the `README.md` from the matching folder in this package:

| Repository name | Description (paste into "About") | Topics |
|---|---|---|
| `ai-research-tools-workshops` | Hands-on Litmaps & Elicit workshops for postgraduate researchers | `litmaps` `elicit` `literature-review` `research-methods` `workshop` |
| `research-journey-toolkit` | Progress tracker & evaluation rubric for postgraduate research projects | `research` `thesis` `rubric` `postgraduate` `template` |
| `ai-for-educators` | Beginner guides & prompt library for teachers using AI (EN/AR) | `ai-in-education` `claude` `prompts` `efl` `teachers` |
| `delta-reading-list` | Curated reading list for the Cambridge DELTA | `delta` `elt` `tefl` `reading-list` `teacher-training` |

Then add your real files:
- **Workshops:** In Google Slides, choose **File → Download → PDF** for the Litmaps and Elicit decks, then upload them to `litmaps/slides/` and `elicit/slides/`.
- **Toolkit:** In Google Sheets, choose **File → Download → .xlsx** for the Progress Tracker and Evaluation Rubric v2, then upload them to `templates/`.
- **AI for Educators:** Upload your Claude screenshots (e.g. `step1-claude-home-screen.png`) to `images/`.
- **DELTA:** Export the "Delta_Reading_List_Burgundy" deck as PDF and upload it to `slides/`.

⚠️ Never upload personal documents such as your passport, ID or residency permit.

## Step 5: Pin your best work
On your profile page, click **Customize your pins** and select all 4 resource repositories and the website.

## Step 6: Fill the placeholders
Search the files for `TODO`. These are hidden comments where your PhD, current job, ORCID, LinkedIn and publications go. Send them to Claude and they will be filled in for you.
