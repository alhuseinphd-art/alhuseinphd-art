# 🔬 AI Research Tools Workshops

Hands-on workshop materials by **Dr. Alhusein Gasmallah** for postgraduate students, researchers and lecturers who want to use AI-powered tools to find, map and manage academic literature.

> **Running example used across the workshops:**
> *AI-Generated Feedback and EFL University Students' Writing Accuracy*
> Every demo uses this topic. In the activities, participants apply each step to **their own** research topic.

---

## 📦 Workshops

### 1. Mapping the Literature with Litmaps
**From your first search to a literature review, in 30 practical steps.**

| | |
|---|---|
| **Format** | Short demo, then hands-on practice for every phase |
| **Length** | About 3.5 hours with one break |
| **Audience** | Postgraduate students, researchers, lecturers |
| **Outcome** | A working literature map for your topic and a draft review outline |

**Phases**
1. Getting started: account setup and your first seed article
2. Searching and discovering connected papers
3. Building and organising your map
4. Monitoring new publications
5. Turning the map into a literature review outline

📁 [`litmaps/`](./litmaps)

### 2. Elicit for Researchers
**Using an AI research assistant to search, screen, extract and export.**

- Asking a research question the way Elicit understands it
- Screening papers and reading summaries critically
- Extracting data into columns (method, sample, findings)
- **Exporting results** (CSV / BibTeX) into your reference manager and spreadsheet

📁 [`elicit/`](./elicit)

---

## 🗂️ Repository structure

```
ai-research-tools-workshops/
├── litmaps/
│   ├── slides/            # Workshop slide deck (PDF)
│   ├── activities/        # Participant worksheets
│   └── facilitator-notes.md
├── elicit/
│   ├── slides/
│   ├── activities/
│   └── facilitator-notes.md
└── README.md
```

## ✅ Principles taught in every session

- AI tools **support**, not replace, the researcher's judgement
- Always **verify** summaries against the original paper
- Keep a transparent record of **how** you searched (for your methods chapter)
- Follow your institution's guidance on **ethical AI use** and academic integrity

## 📩 Book a workshop

Want this workshop for your department or university? Email **alhuseinphd@gmail.com**.

## 📄 License

Slides and worksheets: [CC BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0/). Free to use and adapt for non-commercial teaching, with attribution.
