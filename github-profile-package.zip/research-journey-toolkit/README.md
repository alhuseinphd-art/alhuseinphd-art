# 🧭 Research Journey Toolkit

Practical templates by **Dr. Alhusein Gasmallah** to help postgraduate students **plan, track and evaluate** a research project, from choosing a topic to submitting the thesis.

---

## 🧰 What's inside

| Tool | Format | Use it to… |
|---|---|---|
| **Research Journey Progress Tracker** | Google Sheets / Excel | Break the project into stages, set deadlines and see progress at a glance |
| **Comprehensive Research Evaluation Rubric (v2)** | Google Sheets / Excel | Self-assess or peer-review a proposal, chapter or full thesis against clear criteria |
| **Worked example** | Sheet | See the tracker filled in for a sample EFL research project |

## 📈 Research stages covered by the tracker

1. Topic and research questions
2. Literature search and mapping
3. Literature review writing
4. Methodology and ethics approval
5. Data collection
6. Data analysis
7. Findings and discussion
8. Conclusion, editing and submission

## 📝 Rubric criteria (overview)

- Clarity of the research problem and questions
- Quality and currency of the literature review
- Appropriateness of the methodology
- Rigour of the analysis
- Coherence of argument and structure
- Academic writing, referencing and integrity

## 🚀 How to use

1. Download the files from [`templates/`](./templates), or open the Google Sheets copy link.
2. Choose **File → Make a copy** so you have your own editable version.
3. Fill in your stages and dates, and update the status weekly.
4. Use the rubric before you meet your supervisor.

## 🗂️ Structure

```
research-journey-toolkit/
├── templates/
│   ├── Research_Journey_Progress_Tracker.xlsx
│   ├── Research_Journey_Progress_Tracker_EXAMPLE.xlsx
│   └── Comprehensive_Research_Evaluation_Rubric_v2.xlsx
└── README.md
```

## 📄 License

[CC BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0/). Use and adapt freely for non-commercial education, with attribution.
